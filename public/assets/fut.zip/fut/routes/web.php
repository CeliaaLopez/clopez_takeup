<?php

use App\Http\Controllers\EventController;
use App\Http\Controllers\MessageController;
use App\Http\Controllers\PlayerController;
use Illuminate\Support\Facades\Route;

Route::resource('events', EventController::class)
    ->except('index')
    ->middleware('auth');

Route::resource('events', EventController::class)
    ->only('index');

Route::resource('messages', MessageController::class)
    ->except('store', 'create');
    //->middleware('isAdmin');

Route::resource('messages', MessageController::class)
    ->except('store', 'create')
    ->middleware('auth');

Route::resource('players', PlayerController::class)
    ->only('index');

Route::resource('players', EventController::class)
    ->except('index')
    ->middleware('auth');

//
Route::get('infoContact/conditions', function () {
    return view('infoContact.conditions');
})->name('conditions');

Route::get('infoContact/privacy', function () {
    return view('infoContact.privacy');
})->name('privacy');

Route::get('infoContact/contact', function () {
    return view('infoContact.contact');
})->name('contact');

Route::get('infoContact/location', function () {
    return view('infoContact.location');
})->name('location');


//
Route::get('login', function () {
    return view('login.login');
})->name('login');

Route::get('logout', function () {
    return view('login.logout');
})->name('logout')
    ->middleware('auth');

Route::get('singup', function () {
    return view('login.singup');
})->name('singup');

Route::get('resources', function () {
    return view('resources.account');
})->name('account')
    ->middleware('auth');

Route::get('/', function () {
    return view('index');
})->name('index');