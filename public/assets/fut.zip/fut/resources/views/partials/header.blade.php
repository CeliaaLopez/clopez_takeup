<header>
    <div class="logo">
        <img src="/images/logo.png" style="width: 6em;" alt="logo del equipo">
        Soccer aid
    </div>
    <div class="links">
        <a href="{{route('singup')}}">Registrarse</a>
        <a href="{{route('login')}}">Inicar sesión</a>
        <a href="{{route('logout')}}">Cerrar sesión</a>
        <a href="{{route('account')}}">Cuenta</a>
    </div>
    <div class="secctions">
        <a href="{{route('index')}}">Inicio</a>
        <a href="{{route('players.index')}}">Jugadores</a>
        <a href="{{route('events.index')}}">Eventos</a>
        <a href="{{route('contact')}}">Contacto</a>
        <a href="{{route('location')}}">Donde encontrarnos</a>
        <a href="{{route('players.create')}}">Añadir jugador</a>
        <a href="{{route('events.create')}}">Añadir evento</a>
        <a href="{{route('messages.index')}}">Mensajes</a>
    </div>
</header>
