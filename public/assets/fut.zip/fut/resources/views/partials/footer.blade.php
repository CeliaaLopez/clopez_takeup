<footer>
    <div>Soccer Aid</div>
    <div>Desarrollado por Celia López</div>
    <div class="links">
        <a href="privacy">Política de privacidad</a>
        <a href="conditions">Condiciones de uso</a>
        <a href="contact">Contacto</a>
    </div>
</footer>
