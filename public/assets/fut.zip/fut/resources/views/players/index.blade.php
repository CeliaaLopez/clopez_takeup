@extends('layout')

@section('title', 'Jugadores')

@section('content')
    <h1>Plantilla del Soccer aid</h1>
    @forelse ($players as $player)
        Nombre:
        <a href="{{ route('players.show', $player) }}">
          {{ $player->name ?? 'No tiene nombre' }}
        </a>
        <br>
        {{$player->avatar ?? 'Sin foto'}}
        <br>
    @empty
        No tenemos jugadores aún
    @endforelse
@endsection
