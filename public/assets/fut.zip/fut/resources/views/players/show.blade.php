@extends('layout')

@section('title','Jugador')

@section('content')
 <h2>Jugador {{$player->name}}</h2>
 {{$player->avatar ?? ''}}
 Se encuentra en la posición {{$player->position}}
 <br>
 Redes sociales
 <br>
 Intagram: {{$player->instagram}} || Twitter: {{$player->twitter}} || Twitch: {{$player->twitch}}
@endsection
