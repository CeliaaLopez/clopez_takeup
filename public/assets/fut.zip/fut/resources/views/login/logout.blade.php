@extends('layout')

@section('title','Cerrar Sesión')

@section('content')
@endsection
