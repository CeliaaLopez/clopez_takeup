@extends('layout')

@section('title', 'Inicio Sesión')

@section('content')
    <h2>Inicia sesión</h2>
    <form action="" method="post">
        <label for="name">Nombre/Email</label>
        <input type="text" id="name" name="name">

        <label for="password">Contraseña</label>
        <input type="text" id="password" name="password">
    </form>
@endsection
