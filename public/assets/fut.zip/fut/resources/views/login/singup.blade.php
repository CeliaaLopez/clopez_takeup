@extends('layout')

@section('title', 'Registro')

@section('content')
    <h2>Registrate</h2>
    <form action="" method="post">
        <label for="name">Nombre</label>
        <input type="text" id="name" name="name">

        <label for="email">Email</label>
        <input type="text" id="email" name="email">

        <label for="password">Contraseña</label>
        <input type="text" id="password" name="password">
    </form>
@endsection
