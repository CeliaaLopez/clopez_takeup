@extends('layout')

@section('title', 'Eventos')

@section('content')

    <h2>PARTIDOS OFICIALES</h2>
    @each('events.event', $officialEvents, 'event', 'events.empty')

    <h2>PARTIDOS BENÉFICOS</h2>
    @each('events.event', $charityEvents, 'event', 'events.empty')

    <h2>PARTIDOS DE EXIBICIÓN</h2>
    @each('events.event', $exhibitionEvents, 'event', 'events.empty')

@endsection

