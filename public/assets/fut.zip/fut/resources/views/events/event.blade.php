<a href="{{ route('events.show', $event) }}">
    Nombre: {{ $event->name ?? 'Sin nombre' }}
</a>
<br>
Descripción: {{ $event->description ?? 'No hay descripción' }} <br>
Localización: {{ $event->location ?? 'Sin lugar' }} <br>
Fecha: {{ $event->date ?? 'Por confirmar' }} || Hora: {{ $event->hour ?? 'Por confirmar' }}<br>
<br><br>
