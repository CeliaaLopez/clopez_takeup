@extends('layout')

@section('title', 'Editar evento')

@section('content')
    <h2>Editar evento: {{ $event->name }}</h2>
    <form action="{{ route('events.update', $event) }}" method="post">
        @csrf
        @method('put')

        <label for="name">Nombre</label>
        <input type="text" id="name" name="name" value="{{old('name') ? old('name'):$event->name}}">

        <label for="description">Descripción</label>
        <input type="text" id="description" name="description" value="{{old('description') ? old('description'):$event->description}}">

        <label for="location">Localización</label>
        <input type="text" id="location" name="location" value="{{old('location') ? old('location'):$event->location}}">

        <label for="date">Fecha</label>
        <input type="date" id="date" name="date" value="{{old('date') ? old('date'):$event->date}}">

        <label for="hour">Hora</label>
        <input type="time" id="hour" name="hour" value="{{old('hour') ? old('hour'):$event->hour}}">

        <select name="type" id="type">
            <option value="" disabled>Selecciona tipo de evento</option>
            <option value="official" {{ $event->type == 'official' ? 'selected' : '' }}>Oficial</option>
            <option value="exhibition" {{ $event->type == 'exhibition' ? 'selected' : '' }}>Exibición</option>
            <option value="charity" {{ $event->type == 'charity' ? 'selected' : '' }}>Solidario</option>
        </select>

        <label for="checkbox">¿Quieres que sea visible?</label>
        <input type="checkbox" name="visible" id="visible" {{ $event->visible ? 'checked' : '' }}>

        <label for="tags">Tags</label>
        <input type="text" name="tags" id="tags" value="{{old('tags') ? old('tags'):$event->tags}}">

        <input type="submit" value="Modificar evento">
    </form>


@endsection
