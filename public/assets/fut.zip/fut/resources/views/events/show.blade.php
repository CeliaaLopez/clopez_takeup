@extends('layout')

@section('title','Evento')

@section('content')
<h2>Evento {{$event->name .' '. $event->type}}</h2>
Se realizará el día {{$event->date}} a las {{$event->hour}} en el {{$event->location}}.
<br>
Descripción del partido <br>
{{$event->description}} <br>

<a href="{{route('events.edit', $event) }}">
<button>Editar evento</button>
</a>

<form action="{{ route('events.destroy', $event) }}" method="post">
    @csrf
    @method('delete')
    <input type="submit" value="Eliminar evento">
</form>

@endsection
