@extends('layout')

@section('title', 'Mensajes')

@section('content')
    <h2>Mensajes recibidos</h2>
    @forelse ($messages as $message)
        Nombre: {{ $message->name ?? 'Anónimo' }}
        <br>
        Asunto:
        <a href="{{ route('messages.show', $message) }}">
            {{ $message->subject ?? 'Sin asunto' }}
        </a>
        <br><br>
    @empty
    @endforelse
@endsection
