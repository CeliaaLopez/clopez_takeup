@extends('layout')

@section('title', 'Mensaje')

@section('content')
Name: {{$message->name}}
<br>
Asunto: {{$message->subject}}
<br>
Contenido del mensaje: {{$message->text}}
<br>
<form action="{{ route('messages.destroy', $message) }}" method="post">
    @csrf
    @method('DELETE')
    ¿Desea eliminar el mensaje?
    <input type="submit" value="Eliminar">
</form>
@endsection
