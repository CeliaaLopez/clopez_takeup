@extends('layout')

@section('title', 'Comentarios')

@section('content')
    <br>
    <form action="{{ route('messages.create') }}" method="post">
        <label for="name">Nombre</label>
        <input type="text" name="name" id="name">

        <label for="subject">Asunto</label>
        <input type="text" name="subject" id="subject"><br>

        <label for="text">Mensaje</label> <br>
        <textarea type="text" name="text" id="text">
            Deja tu comentario...
        </textarea>
        @method('put')
        @csrf
    </form>

@endsection
