<?php $__env->startSection('title', 'Comentarios'); ?>

<?php $__env->startSection('content'); ?>
    <form action="" method="post">
        <label for="name">Nombre</label>
        <input type="text" name="name" id="name">

        <label for="subject">Asunto</label>
        <input type="text" name="subject" id="subject"><br>

        <label for="text">Mensaje</label> <br>
        <textarea type="text" name="text" id="text">Deja tu comentario...</textarea>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH A:\laragon\www\FootballTeamCelia\resources\views/infoContact/contact.blade.php ENDPATH**/ ?>