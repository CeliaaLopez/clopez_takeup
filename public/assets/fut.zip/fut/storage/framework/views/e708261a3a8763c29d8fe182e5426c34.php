<div>
    No hay eventos de esta categoría.
</div>
<?php /**PATH C:\laragon\www\FootballTeamCelia\resources\views/events/empty.blade.php ENDPATH**/ ?>