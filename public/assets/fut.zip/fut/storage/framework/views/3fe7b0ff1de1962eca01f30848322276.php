<?php $__env->startSection('title','Evento'); ?>

<?php $__env->startSection('content'); ?>
<h2>Evento <?php echo e($event->name .' '. $event->type); ?></h2>
Se realizará el día <?php echo e($event->date); ?> a las <?php echo e($event->hour); ?> en el <?php echo e($event->location); ?>.
<br>
Descripción del partido <br>
<?php echo e($event->description); ?> <br>

<a href="<?php echo e(route('events.edit', $event)); ?>">
<button>Editar evento</button>
</a>

<form action="<?php echo e(route('events.destroy', $event)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('delete'); ?>
    <input type="submit" value="Eliminar evento">
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH A:\laragon\www\FootballTeamCelia\resources\views/events/show.blade.php ENDPATH**/ ?>