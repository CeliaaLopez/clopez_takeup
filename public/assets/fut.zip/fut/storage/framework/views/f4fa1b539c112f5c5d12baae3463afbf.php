<?php $__env->startSection('title', 'Editar evento'); ?>

<?php $__env->startSection('content'); ?>
    <h2>Editar evento: <?php echo e($event->name); ?></h2>
    <form action="<?php echo e(route('events.update', $event)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>

        <label for="name">Nombre</label>
        <input type="text" id="name" name="name" value="<?php echo e(old('name') ? old('name'):$event->name); ?>">

        <label for="description">Descripción</label>
        <input type="text" id="description" name="description" value="<?php echo e(old('description') ? old('description'):$event->description); ?>">

        <label for="location">Localización</label>
        <input type="text" id="location" name="location" value="<?php echo e(old('location') ? old('location'):$event->location); ?>">

        <label for="date">Fecha</label>
        <input type="date" id="date" name="date" value="<?php echo e(old('date') ? old('date'):$event->date); ?>">

        <label for="hour">Hora</label>
        <input type="time" id="hour" name="hour" value="<?php echo e(old('hour') ? old('hour'):$event->hour); ?>">

        <select name="type" id="type">
            <option value="" disabled>Selecciona tipo de evento</option>
            <option value="official" <?php echo e($event->type == 'official' ? 'selected' : ''); ?>>Oficial</option>
            <option value="exhibition" <?php echo e($event->type == 'exhibition' ? 'selected' : ''); ?>>Exibición</option>
            <option value="charity" <?php echo e($event->type == 'charity' ? 'selected' : ''); ?>>Solidario</option>
        </select>

        <label for="checkbox">¿Quieres que sea visible?</label>
        <input type="checkbox" name="visible" id="visible" <?php echo e($event->visible ? 'checked' : ''); ?>>

        <label for="tags">Tags</label>
        <input type="text" name="tags" id="tags" value="<?php echo e(old('tags') ? old('tags'):$event->tags); ?>">

        <input type="submit" value="Modificar evento">
    </form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\FootballTeamCelia\resources\views/events/edit.blade.php ENDPATH**/ ?>