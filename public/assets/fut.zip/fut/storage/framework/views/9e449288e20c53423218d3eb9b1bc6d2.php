<?php $__env->startSection('title', 'Editar evento'); ?>

<?php $__env->startSection('content'); ?>
<h2>Editar evento: <?php echo e($event->name); ?></h2>
<form action="<?php echo e(route('events.update', $event)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>

    <label for="name">Nombre</label>
    <input type="text" id="name" name="name">

    <label for="description">Descripción</label>
    <input type="text" id="description" name="description">

    <label for="location">Localización</label>
    <input type="text" id="location" name="location">

    <label for="date">Fecha</label>
    <input type="text" id="date" name="date">

    <label for="hour">Hora</label>
    <input type="text" id="hour" name="hour">

    <label for="type">Tipo de evento</label>
    <input type="text" id="type" name="type">

    <input type="submit" value="Modificar evento">
</form>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH A:\laragon\www\FootballTeamCelia\resources\views/events/edit.blade.php ENDPATH**/ ?>