<?php $__env->startSection('title','Cerrar Sesión'); ?>

<?php $__env->startSection('content'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH A:\laragon\www\FootballTeamCelia\resources\views/login/logout.blade.php ENDPATH**/ ?>