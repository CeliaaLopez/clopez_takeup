<?php $__env->startSection('title','Inicio'); ?>

<?php $__env->startSection('content'); ?>
<div class="imgGroup">
    <img src="/images/principal.jpg" style="width: 40vw; height: 30em;" alt="foto principal de soccer aid">
</div>
<div class="description">
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Praesentium quidem iure repudiandae laborum optio modi, hic, necessitatibus impedit earum officia dolorum quia voluptate ducimus, reiciendis cupiditate quae tenetur dolor consequuntur?
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis atque voluptate laboriosam consequatur quia sequi. Quam quod repudiandae numquam magni? Sint, officia quo tempore hic reiciendis ea exercitationem ullam architecto.
    Sunt eligendi illo magnam magni odit amet, dolorum dolore perferendis, adipisci ipsam ab ipsa placeat cupiditate minus porro quod? Hic minus laudantium at consequuntur, sunt possimus natus ipsa molestiae quaerat.
    Enim explicabo modi nulla, quas autem aliquid nostrum suscipit accusamus quia ipsa harum error itaque dignissimos laudantium veniam. Atque odit totam similique sunt pariatur voluptatum repudiandae rerum. Temporibus, inventore saepe?
    Laborum voluptatibus praesentium laboriosam veniam iure molestiae maiores reiciendis vero nisi quo, beatae illo nemo eius exercitationem iste aliquam nostrum obcaecati incidunt, nam dolore facilis? Ullam dolorum velit corrupti saepe.
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam voluptatem doloribus accusantium aliquam distinctio at commodi nemo, laudantium possimus nam expedita repudiandae! Id vero voluptatem, aperiam eveniet enim quam earum!
    Nobis architecto harum quidem. Iste dolorem excepturi molestias. Velit accusantium eligendi officia porro repudiandae. Eveniet facere labore consectetur aliquid amet sed blanditiis quidem ipsa suscipit repellendus, voluptatem fugiat, perferendis dolorum!
    Quod accusantium tempora, minus non libero inventore enim, error itaque officiis earum magnam qui alias rem consectetur deleniti debitis recusandae facere? Ipsum mollitia iure reprehenderit voluptates adipisci illum fuga voluptatibus!
    Fugiat eum assumenda veritatis velit itaque perspiciatis, cumque officia reprehenderit, dicta doloremque ducimus! Nam recusandae unde sapiente, ducimus at fuga vitae accusamus ex similique nostrum maiores nulla corporis quam esse?
    Iste deleniti eos, eius reiciendis cumque assumenda aspernatur distinctio id repellat quo optio! Numquam quibusdam magnam atque, quam enim veritatis odio est doloribus rem aut rerum excepturi! Laboriosam, illo eius.
    Corrupti eius sapiente illum beatae voluptatibus explicabo esse. Dicta nobis nam modi ab, quis fuga id sint odio, distinctio sit possimus cum excepturi vel tempore minima ullam, recusandae accusantium. Ipsum?
    Magni numquam fugit et alias aliquid cupiditate! Sit tempore voluptates neque, laudantium optio aut temporibus error inventore sapiente culpa velit aperiam, et dolore harum perspiciatis! Molestiae tempora enim accusantium sit.
    Expedita culpa similique dolor iure excepturi suscipit sequi voluptatibus. Earum illo necessitatibus, quibusdam modi aliquam ab excepturi deserunt atque consectetur harum distinctio rerum. Minima obcaecati excepturi impedit molestias nesciunt placeat?
    Quaerat ipsum illum quam quod dignissimos totam, libero alias obcaecati incidunt nihil quos? Delectus obcaecati nemo quaerat! Perspiciatis temporibus porro fugiat consequatur suscipit vitae ea eum totam possimus, quas perferendis.
    Suscipit corrupti dolore modi ducimus, rerum nemo recusandae laborum impedit! Consectetur vero, est omnis ea esse blanditiis quis suscipit voluptatibus atque commodi mollitia, unde eaque impedit fugiat veniam explicabo eveniet?
    Repellat consequuntur itaque ratione, soluta quod laborum mollitia dolor id amet numquam, quae doloribus eius officiis debitis necessitatibus doloremque praesentium alias sapiente ipsam reiciendis velit in aliquam rerum nihil. Explicabo.
    Commodi itaque sequi dicta error assumenda obcaecati quisquam vel. Neque illo qui nobis ipsa. Hic eum totam quibusdam dignissimos cum, neque commodi dolorem voluptas expedita accusamus sequi inventore consequuntur perferendis.
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\FootballTeamCelia\resources\views/index.blade.php ENDPATH**/ ?>