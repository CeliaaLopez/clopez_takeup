<a href="<?php echo e(route('events.show', $event)); ?>">
    Nombre: <?php echo e($event->name ?? 'Sin nombre'); ?>

</a>
<br>
Descripción: <?php echo e($event->description ?? 'No hay descripción'); ?> <br>
Localización: <?php echo e($event->location ?? 'Sin lugar'); ?> <br>
Fecha: <?php echo e($event->date ?? 'Por confirmar'); ?> || Hora: <?php echo e($event->hour ?? 'Por confirmar'); ?><br>
<br><br>
<?php /**PATH C:\laragon\www\FootballTeamCelia\resources\views/events/event.blade.php ENDPATH**/ ?>