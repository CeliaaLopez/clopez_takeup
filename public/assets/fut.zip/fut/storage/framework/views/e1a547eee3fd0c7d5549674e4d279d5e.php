<?php $__env->startSection('title', 'Mensaje'); ?>

<?php $__env->startSection('content'); ?>
Name: <?php echo e($message->name); ?>

<br>
Asunto: <?php echo e($message->subject); ?>

<br>
Contenido del mensaje: <?php echo e($message->text); ?>

<br>
<form action="<?php echo e(route('messages.destroy', $message)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    ¿Desea eliminar el mensaje?
    <input type="submit" value="Eliminar">
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH A:\laragon\www\FootballTeamCelia\resources\views/messages/show.blade.php ENDPATH**/ ?>