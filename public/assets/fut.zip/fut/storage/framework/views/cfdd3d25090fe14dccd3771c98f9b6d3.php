<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php $__env->startSection('title','Error'); ?></title>
</head>
<body>

<?php $__env->startSection('body_page'); ?>
    <h3>Error, no se ha encontrado el contenido</h3>
<?php $__env->stopSection(); ?>
</body>
</html>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\FootballTeamCelia\resources\views/errors/404.blade.php ENDPATH**/ ?>