<?php $__env->startSection('title','Localización'); ?>

<?php $__env->startSection('content'); ?>
<h2>Ven a ver tu equipo favorito en el Etihad Stadium!</h2>
<div>
    <h3>Ubicación</h3>
    <div>
        <img src="/images/estadio2.webp" style="width:40em; height: 30em;" alt="imagen del estadio soccer aid">
        <img src="/images/estadio.webp" style="width:40em; height: 30em;" alt="imagen del estadio soccer aid">
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m17!1m12!1m3!1d2374.177850477416!2d-2.202983923260011!3d53.48315197232923!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m2!1m1!2zNTPCsDI4JzU5LjQiTiAywrAxMicwMS41Ilc!5e0!3m2!1ses!2ses!4v1738092122208!5m2!1ses!2ses" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade">
    </iframe>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH A:\laragon\www\FootballTeamCelia\resources\views/infoContact/location.blade.php ENDPATH**/ ?>