<div>
    No hay eventos de esta categoría.
</div>
<?php /**PATH A:\laragon\www\FootballTeamCelia\resources\views/events/empty.blade.php ENDPATH**/ ?>