<?php $__env->startSection('title', 'Eventos'); ?>

<?php $__env->startSection('content'); ?>

    <h2>PARTIDOS OFICIALES</h2>
    <?php echo $__env->renderEach('events.event', $officialEvents, 'event', 'events.empty'); ?>

    <h2>PARTIDOS BENÉFICOS</h2>
    <?php echo $__env->renderEach('events.event', $charityEvents, 'event', 'events.empty'); ?>

    <h2>PARTIDOS DE EXIBICIÓN</h2>
    <?php echo $__env->renderEach('events.event', $exhibitionEvents, 'event', 'events.empty'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH A:\laragon\www\FootballTeamCelia\resources\views/events/index.blade.php ENDPATH**/ ?>