<?php $__env->startSection('title','Jugador'); ?>

<?php $__env->startSection('content'); ?>
 <h2>Jugador <?php echo e($player->name); ?></h2>
 <?php echo e($player->avatar ?? ''); ?>

 Se encuentra en la posición <?php echo e($player->position); ?>

 <br>
 Redes sociales
 <br>
 Intagram: <?php echo e($player->instagram); ?> || Twitter: <?php echo e($player->twitter); ?> || Twitch: <?php echo e($player->twitch); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH A:\laragon\www\FootballTeamCelia\resources\views/players/show.blade.php ENDPATH**/ ?>