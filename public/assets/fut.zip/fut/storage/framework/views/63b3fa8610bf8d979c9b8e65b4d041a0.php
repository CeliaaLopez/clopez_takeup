<?php $__env->startSection('title', 'Mensajes'); ?>

<?php $__env->startSection('content'); ?>
    <h2>Mensajes recibidos</h2>
    <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        Nombre: <?php echo e($message->name ?? 'Anónimo'); ?>

        <br>
        Asunto:
        <a href="<?php echo e(route('messages.show', $message)); ?>">
            <?php echo e($message->subject ?? 'Sin asunto'); ?>

        </a>
        <br><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\FootballTeamCelia\resources\views/messages/index.blade.php ENDPATH**/ ?>