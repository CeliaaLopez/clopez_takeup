<?php $__env->startSection('title', 'Registro'); ?>

<?php $__env->startSection('content'); ?>
    <h2>Registrate</h2>
    <form action="" method="post">
        <label for="name">Nombre</label>
        <input type="text" id="name" name="name">

        <label for="email">Email</label>
        <input type="text" id="email" name="email">

        <label for="password">Contraseña</label>
        <input type="text" id="password" name="password">
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH A:\laragon\www\FootballTeamCelia\resources\views/login/singup.blade.php ENDPATH**/ ?>