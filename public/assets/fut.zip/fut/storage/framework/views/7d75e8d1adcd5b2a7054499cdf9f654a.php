<?php $__env->startSection('title', 'Jugadores'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Plantilla del Soccer aid</h1>
    <?php $__empty_1 = true; $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        Nombre:
        <a href="<?php echo e(route('players.show', $player)); ?>">
          <?php echo e($player->name ?? 'No tiene nombre'); ?>

        </a>
        <br>
        <?php echo e($player->avatar ?? 'Sin foto'); ?>

        <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        No tenemos jugadores aún
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH A:\laragon\www\FootballTeamCelia\resources\views/players/index.blade.php ENDPATH**/ ?>