<header>
    <div class="logo">
        <img src="/images/logo.png" style="width: 6em;" alt="logo del equipo">
        Soccer aid
    </div>
    <div class="links">
        <a href="<?php echo e(route('singup')); ?>">Registrarse</a>
        <a href="<?php echo e(route('login')); ?>">Inicar sesión</a>
        <a href="<?php echo e(route('logout')); ?>">Cerrar sesión</a>
        <a href="<?php echo e(route('account')); ?>">Cuenta</a>
    </div>
    <div class="secctions">
        <a href="<?php echo e(route('index')); ?>">Inicio</a>
        <a href="<?php echo e(route('players.index')); ?>">Jugadores</a>
        <a href="<?php echo e(route('events.index')); ?>">Eventos</a>
        <a href="<?php echo e(route('contact')); ?>">Contacto</a>
        <a href="<?php echo e(route('location')); ?>">Donde encontrarnos</a>
        <a href="<?php echo e(route('players.create')); ?>">Añadir jugador</a>
        <a href="<?php echo e(route('events.create')); ?>">Añadir evento</a>
        <a href="<?php echo e(route('messages.index')); ?>">Mensajes</a>
    </div>
</header>
<?php /**PATH C:\laragon\www\FootballTeamCelia\resources\views/partials/header.blade.php ENDPATH**/ ?>